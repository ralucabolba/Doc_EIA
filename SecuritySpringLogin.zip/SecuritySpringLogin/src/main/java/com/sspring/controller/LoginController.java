package com.sspring.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sspring.bean.UserBean;

@Controller
public class LoginController {
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView firstPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("login");
		return model;
	}

	@RequestMapping(value = "/success**", method = RequestMethod.GET)
	public ModelAndView successPage() {
		ModelAndView model = new ModelAndView();
		
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		List<UserBean> users = (List<UserBean>) context.getBean("userList");
		
		model.addObject("userList", users);
		model.setViewName("success");
		return model;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView submitLogin(@RequestParam(value = "error", required = false) String error,
			@RequestParam(value = "logout", required = false) String logout) {
		ModelAndView model = new ModelAndView();

		if (error != null) {
			model.addObject("errorMessage", "Invalid username and password");
		}

		if (logout != null) {
			model.addObject("logoutMessage", "Logged out successfully");
		}

		model.setViewName("login");

		return model;
	}

}
