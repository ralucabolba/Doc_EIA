package com.test.login.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.test.login.bean.User;

/**
 * Servlet class for login request. It checks if the credentials are correct and proceeds accordingly
 * @author ralucab
 */

public class CheckCredentials extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String username = request.getParameter("username");
		String password = request.getParameter("password");

		if ("raluca".equals(username) && "maria".equals(password)) {
			request.getSession().setAttribute("loggedIn", true);
			
			List<User> users = generateTestList();
			request.setAttribute("userList", users);
			RequestDispatcher rd = request.getRequestDispatcher("users.jsp");
			
			rd.forward(request, response);
		} else {
			request.getSession().setAttribute("errorMessage", "Incorrect username or password");
			response.sendRedirect("login.jsp");
		}
	}
	
	/**
	 * Method that generates a list of users for testing purposes
	 * @return a list of User objects
	 */
	private List<User> generateTestList(){
		User user1 = new User();
		user1.setUsername("raluca");
		user1.setPassword("maria");
		user1.setName("Bolba Raluca");
		user1.setAge(22);
		user1.setSalary(100.0);
		
		User user2 = new User();
		user2.setUsername("marilena");
		user2.setPassword("alabala");
		user2.setName("Pop Marinela");
		user2.setAge(30);
		user2.setSalary(150.0);
		
		User user3 = new User();
		user3.setUsername("adrian");
		user3.setPassword("artsoft");
		user3.setName("Gozar Adrian");
		user3.setAge(35);
		user3.setSalary(2000.0);
		
		User user4 = new User();
		user4.setUsername("cristina");
		user4.setPassword("fbasdjkfg");
		user4.setName("Negrean Cristina");
		user4.setAge(18);
		user4.setSalary(0.0);
		
		List<User> users = new ArrayList<User>();
		
		users.add(user1);
		users.add(user2);
		users.add(user3);
		users.add(user4);
		
		return users;
	}

}
