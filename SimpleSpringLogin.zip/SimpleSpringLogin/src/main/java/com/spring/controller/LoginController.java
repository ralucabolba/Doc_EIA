package com.spring.controller;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.bean.UserBean;

@Controller
public class LoginController {
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView firstPage() {
		ModelAndView model = new ModelAndView();
		model.setViewName("login");
		return model;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView submit(@ModelAttribute("loginBean") UserBean loginBean) {
		ModelAndView model = new ModelAndView();
		if (loginBean != null && loginBean.getUsername() != null & loginBean.getPassword() != null) {
			if (loginBean.getUsername().equals("raluca") && loginBean.getPassword().equals("maria")) {

				// generate list of dummy users and send it to success page in
				// order to display them

				ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

				List<UserBean> users = (List<UserBean>) context.getBean("userList");

				model.addObject("userList", users);
				model.setViewName("success");
			} else {
				model.addObject("errorMessage", "Incorrect username or password");
				model.setViewName("login");
			}
		} else {
			model.addObject("errorMessage", "Incorrect username or password");
			model.setViewName("login");
		}

		return model;
	}
}
